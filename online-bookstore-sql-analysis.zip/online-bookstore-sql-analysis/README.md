# Online Bookstore SQL Analysis

A PostgreSQL project that analyses a small online bookstore: revenue, popular books, customer spending and inventory. It goes from basic filtering to window functions, using 3 related tables and 25+ queries.

## Dataset

Sample (synthetic) data with 500 rows in each table, covering orders from December 2022 to December 2024.

| Table | Rows | Description |
|---|---|---|
| `books` | 500 | Title, author, genre, published year, price, stock |
| `customers` | 500 | Name, email, phone, city, country |
| `orders` | 500 | Which customer bought which book, when, how many, and the total amount |

```mermaid
erDiagram
    CUSTOMERS ||--o{ ORDERS : places
    BOOKS ||--o{ ORDERS : "is ordered in"
    BOOKS {
        int book_id PK
        varchar title
        varchar author
        varchar genre
        int published_year
        numeric price
        int stock
    }
    CUSTOMERS {
        int customer_id PK
        varchar name
        varchar email
        varchar phone
        varchar city
        varchar country
    }
    ORDERS {
        int order_id PK
        int customer_id FK
        int book_id FK
        date order_date
        int quantity
        numeric total_amount
    }
```

## Repository structure

```
online-bookstore-sql-analysis/
├── README.md
├── data/
│   ├── Books.csv
│   ├── Customers.csv
│   └── Orders.csv
└── sql/
    ├── 01_schema.sql              # create tables, keys and constraints
    ├── 02_import_data.sql         # load the CSVs, fix ID sequences, sanity check
    ├── 03_basic_queries.sql       # filtering, sorting, simple joins
    ├── 04_business_analysis.sql   # revenue, popular books, customers, inventory
    └── 05_advanced_analysis.sql   # trends, window functions, segmentation
```

## How to run it

**Requirements:** PostgreSQL 14+ and `psql` (pgAdmin also works).

```bash
# 1. Create the database
psql -U postgres -c "CREATE DATABASE onlinebookstore;"

# 2. From the root of this repo, create the tables and load the data
psql -U postgres -d onlinebookstore -f sql/01_schema.sql
psql -U postgres -d onlinebookstore -f sql/02_import_data.sql

# 3. Run any analysis file
psql -U postgres -d onlinebookstore -f sql/04_business_analysis.sql
```

Run step 2 from the repo root, because the import script uses relative paths to `data/`. If you use pgAdmin, the import steps are described at the top of `02_import_data.sql`.

## What the queries cover

| Theme | Questions answered |
|---|---|
| **Revenue** | Total revenue and average order value, orders above $20, revenue by genre, cities of high-spending customers |
| **Popular books** | Most ordered books (ties handled with `RANK()`), top books by units sold, sales per genre and per author |
| **Customer spending** | Biggest spenders, customers with 2+ orders |
| **Inventory** | Lowest stock, stock remaining after all orders, books ordered beyond their stock |
| **Advanced** | Monthly revenue with month-over-month growth, best book per genre, spend tiers, repeat vs one-time buyers |

## Key findings

- **Revenue:** $75,628.66 from 500 orders and 2,697 books sold, an average order value of $151.26.
- **Genres:** Romance earns the most revenue ($13,086.98), while Mystery sells the most copies (504). Fiction is last on both.
- **Customers:** only 307 of 500 customers have placed an order. 139 of them (45.3%) ordered more than once.
- **Concentration:** the 36 customers who spent $500 or more account for about 32% of revenue. The top spender is Kim Turner at $1,398.90.
- **Trend:** the strongest months were May 2023 ($5,110.81) and January 2024 ($4,904.57). December 2024 is a partial month because the data stops on 7 December.
- **Inventory:** 5 books have zero stock, and 30 books have more units ordered than the recorded stock. The stock column appears to be a standalone snapshot, so this is a data-quality flag to check, not a real oversell.

## Skills demonstrated

- Relational schema design with primary keys, foreign keys and constraints
- Data loading and validation with `\copy`
- Multi-table `JOIN`s and `LEFT JOIN` with `COALESCE`
- `GROUP BY` / `HAVING` aggregation
- CTEs and window functions (`RANK`, `LAG`, running totals)
- `DATE_TRUNC` time-series analysis and `CASE WHEN` segmentation
- Handling ties, partial periods and data-quality checks

## Author

**[Your Name]** · [LinkedIn](https://www.linkedin.com/in/your-profile) · [GitHub](https://github.com/your-username)
