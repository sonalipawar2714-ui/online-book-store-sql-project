-- =============================================================
-- Online Bookstore SQL Analysis | 02_import_data.sql
-- Purpose : Load the CSV files from /data into the tables
--
-- Run this with psql from the ROOT of the repository, so the
-- relative paths below resolve:
--     psql -U postgres -d onlinebookstore -f sql/02_import_data.sql
--
-- Using pgAdmin instead? Right-click each table > Import/Export
-- Data, choose the CSV, set Header = ON, Delimiter = ",".
-- Load in this order: books, customers, orders.
-- =============================================================

\copy books (book_id, title, author, genre, published_year, price, stock) FROM 'data/Books.csv' WITH (FORMAT csv, HEADER true)
\copy customers (customer_id, name, email, phone, city, country) FROM 'data/Customers.csv' WITH (FORMAT csv, HEADER true)
\copy orders (order_id, customer_id, book_id, order_date, quantity, total_amount) FROM 'data/Orders.csv' WITH (FORMAT csv, HEADER true)

-- IDs were loaded explicitly, so move the SERIAL counters past them
SELECT setval(pg_get_serial_sequence('books', 'book_id'),         (SELECT MAX(book_id) FROM books));
SELECT setval(pg_get_serial_sequence('customers', 'customer_id'), (SELECT MAX(customer_id) FROM customers));
SELECT setval(pg_get_serial_sequence('orders', 'order_id'),       (SELECT MAX(order_id) FROM orders));

-- Sanity check: expect 500 / 500 / 500
SELECT
    (SELECT COUNT(*) FROM books)     AS books,
    (SELECT COUNT(*) FROM customers) AS customers,
    (SELECT COUNT(*) FROM orders)    AS orders;
