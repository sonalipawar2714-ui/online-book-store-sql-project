-- =============================================================
-- Online Bookstore SQL Analysis | 04_business_analysis.sql
-- Level : Intermediate (joins, GROUP BY / HAVING, CTEs, RANK)
-- Themes: 1 Revenue | 2 Popular books | 3 Customer spending
--         4 Inventory
-- =============================================================


-- =============================================================
-- THEME 1: REVENUE ANALYSIS
-- =============================================================

-- 1.1 Headline numbers: revenue, orders, units sold, avg order value
SELECT ROUND(SUM(total_amount), 2) AS total_revenue,
       COUNT(*)                    AS total_orders,
       SUM(quantity)               AS units_sold,
       ROUND(AVG(total_amount), 2) AS avg_order_value
FROM orders;

-- 1.2 Orders where the total amount exceeds $20
SELECT *
FROM orders
WHERE total_amount > 20
ORDER BY total_amount DESC;

-- 1.3 Revenue by genre
SELECT b.genre,
       ROUND(SUM(o.total_amount), 2) AS revenue
FROM orders o
JOIN books b ON b.book_id = o.book_id
GROUP BY b.genre
ORDER BY revenue DESC;

-- 1.4 Cities of customers whose TOTAL spend is over $30
-- (a customer's spend is summed across all of their orders)
WITH customer_spend AS (
    SELECT customer_id,
           SUM(total_amount) AS total_spent
    FROM orders
    GROUP BY customer_id
)
SELECT c.city,
       c.country,
       COUNT(*)                     AS customers_over_30,
       ROUND(SUM(cs.total_spent), 2) AS combined_spend
FROM customer_spend cs
JOIN customers c ON c.customer_id = cs.customer_id
WHERE cs.total_spent > 30
GROUP BY c.city, c.country
ORDER BY combined_spend DESC
LIMIT 10;


-- =============================================================
-- THEME 2: POPULAR BOOKS
-- =============================================================

-- 2.1 Most frequently ordered book(s), by number of orders
-- RANK() keeps ties, instead of LIMIT 1 silently hiding them
WITH order_counts AS (
    SELECT b.book_id,
           b.title,
           COUNT(o.order_id) AS order_count,
           RANK() OVER (ORDER BY COUNT(o.order_id) DESC) AS rnk
    FROM orders o
    JOIN books b ON b.book_id = o.book_id
    GROUP BY b.book_id, b.title
)
SELECT book_id, title, order_count
FROM order_counts
WHERE rnk = 1
ORDER BY book_id;

-- 2.2 Top 5 books by units sold
SELECT b.book_id,
       b.title,
       SUM(o.quantity) AS units_sold
FROM orders o
JOIN books b ON b.book_id = o.book_id
GROUP BY b.book_id, b.title
ORDER BY units_sold DESC, b.book_id
LIMIT 5;

-- 2.3 Units sold per genre
SELECT b.genre,
       SUM(o.quantity) AS total_books_sold
FROM orders o
JOIN books b ON b.book_id = o.book_id
GROUP BY b.genre
ORDER BY total_books_sold DESC;

-- 2.4 Units sold per author (top 10)
SELECT b.author,
       SUM(o.quantity) AS total_books_sold
FROM orders o
JOIN books b ON b.book_id = o.book_id
GROUP BY b.author
ORDER BY total_books_sold DESC, b.author
LIMIT 10;

-- 2.5 Top 3 most expensive Fantasy books
SELECT *
FROM books
WHERE genre = 'Fantasy'
ORDER BY price DESC
LIMIT 3;


-- =============================================================
-- THEME 3: CUSTOMER SPENDING
-- =============================================================

-- 3.1 Top 5 customers by total spend (first row = biggest spender)
SELECT c.customer_id,
       c.name,
       COUNT(o.order_id)             AS orders_placed,
       ROUND(SUM(o.total_amount), 2) AS total_spent
FROM orders o
JOIN customers c ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.name
ORDER BY total_spent DESC
LIMIT 5;

-- 3.2 Customers who placed at least 2 orders
SELECT c.customer_id,
       c.name,
       COUNT(o.order_id)             AS orders_placed,
       ROUND(SUM(o.total_amount), 2) AS total_spent
FROM orders o
JOIN customers c ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.name
HAVING COUNT(o.order_id) >= 2
ORDER BY orders_placed DESC, total_spent DESC;


-- =============================================================
-- THEME 4: INVENTORY
-- =============================================================

-- 4.1 Book(s) with the lowest stock, ties included
SELECT *
FROM books
WHERE stock = (SELECT MIN(stock) FROM books)
ORDER BY book_id;

-- 4.2 Stock remaining after fulfilling all orders
SELECT b.book_id,
       b.title,
       b.stock,
       COALESCE(SUM(o.quantity), 0)           AS ordered_quantity,
       b.stock - COALESCE(SUM(o.quantity), 0) AS remaining_quantity
FROM books b
LEFT JOIN orders o ON o.book_id = b.book_id
GROUP BY b.book_id, b.title, b.stock
ORDER BY b.book_id;

-- 4.3 Data check: books where ordered quantity is MORE than stock
-- (stock looks like a standalone snapshot, so these show as negative)
SELECT b.book_id,
       b.title,
       b.stock,
       SUM(o.quantity)             AS ordered_quantity,
       b.stock - SUM(o.quantity)   AS remaining_quantity
FROM books b
JOIN orders o ON o.book_id = b.book_id
GROUP BY b.book_id, b.title, b.stock
HAVING SUM(o.quantity) > b.stock
ORDER BY remaining_quantity;
