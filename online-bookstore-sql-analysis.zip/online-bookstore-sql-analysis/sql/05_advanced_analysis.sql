-- =============================================================
-- Online Bookstore SQL Analysis | 05_advanced_analysis.sql
-- Level : Advanced (DATE_TRUNC, window functions, CASE WHEN)
-- Extra analysis added on top of the core question set.
-- =============================================================

-- A1. Monthly revenue trend with month-over-month growth and
--     cumulative revenue
-- Note: the data ends on 2024-12-07, so Dec 2024 is a partial month.
WITH monthly AS (
    SELECT DATE_TRUNC('month', order_date)::date AS month,
           SUM(total_amount)                     AS revenue,
           COUNT(*)                              AS orders
    FROM orders
    GROUP BY 1
)
SELECT month,
       orders,
       ROUND(revenue, 2) AS revenue,
       ROUND(100.0 * (revenue - LAG(revenue) OVER (ORDER BY month))
             / NULLIF(LAG(revenue) OVER (ORDER BY month), 0), 1) AS mom_growth_pct,
       ROUND(SUM(revenue) OVER (ORDER BY month), 2)              AS cumulative_revenue
FROM monthly
ORDER BY month;

-- A2. Best-selling book in each genre (by revenue)
WITH book_revenue AS (
    SELECT b.genre,
           b.title,
           SUM(o.total_amount) AS revenue,
           RANK() OVER (PARTITION BY b.genre
                        ORDER BY SUM(o.total_amount) DESC) AS rnk
    FROM orders o
    JOIN books b ON b.book_id = o.book_id
    GROUP BY b.genre, b.title
)
SELECT genre,
       title,
       ROUND(revenue, 2) AS revenue
FROM book_revenue
WHERE rnk = 1
ORDER BY revenue DESC;

-- A3. Customer spend tiers
-- Thresholds ($200 / $500) sit near the median and 90th percentile
-- of customer spend in this dataset.
WITH customer_spend AS (
    SELECT c.customer_id,
           c.name,
           COALESCE(SUM(o.total_amount), 0) AS total_spent
    FROM customers c
    LEFT JOIN orders o ON o.customer_id = c.customer_id
    GROUP BY c.customer_id, c.name
)
SELECT CASE
           WHEN total_spent = 0   THEN '0 - No orders'
           WHEN total_spent < 200 THEN '1 - Low (under $200)'
           WHEN total_spent < 500 THEN '2 - Medium ($200-$499)'
           ELSE                        '3 - High ($500+)'
       END                           AS spend_tier,
       COUNT(*)                      AS customers,
       ROUND(SUM(total_spent), 2)    AS tier_revenue
FROM customer_spend
GROUP BY 1
ORDER BY 1;

-- A4. Repeat vs one-time buyers (among customers who ordered)
WITH order_counts AS (
    SELECT customer_id, COUNT(*) AS orders_placed
    FROM orders
    GROUP BY customer_id
)
SELECT CASE WHEN orders_placed = 1 THEN 'One-time' ELSE 'Repeat (2+)' END AS buyer_type,
       COUNT(*)                                                           AS customers,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1)                 AS pct_of_buyers
FROM order_counts
GROUP BY 1
ORDER BY 1;
