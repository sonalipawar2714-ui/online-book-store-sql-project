-- =============================================================
-- Online Bookstore SQL Analysis | 03_basic_queries.sql
-- Level : Basic (filtering, sorting, simple aggregation, joins)
-- =============================================================

-- B1. All books in the Fiction genre
SELECT *
FROM books
WHERE genre = 'Fiction';

-- B2. Books published after 1950
SELECT *
FROM books
WHERE published_year > 1950;

-- B3. Customers from Canada
SELECT *
FROM customers
WHERE country = 'Canada';

-- B4. Orders placed in November 2023
-- (half-open range works for DATE and for TIMESTAMP columns)
SELECT *
FROM orders
WHERE order_date >= DATE '2023-11-01'
  AND order_date <  DATE '2023-12-01';

-- B5. Total stock of books available
SELECT SUM(stock) AS total_stock
FROM books;

-- B6. Most expensive book(s), ties included
SELECT *
FROM books
WHERE price = (SELECT MAX(price) FROM books);

-- B7. Orders with more than 1 copy, with customer and book names
SELECT o.order_id,
       c.name  AS customer,
       b.title AS book,
       o.quantity
FROM orders o
JOIN customers c ON c.customer_id = o.customer_id
JOIN books b     ON b.book_id     = o.book_id
WHERE o.quantity > 1
ORDER BY o.quantity DESC, o.order_id;

-- B8. All genres available
SELECT DISTINCT genre
FROM books
ORDER BY genre;

-- B9. Average price of Fantasy books
SELECT ROUND(AVG(price), 2) AS avg_fantasy_price
FROM books
WHERE genre = 'Fantasy';
