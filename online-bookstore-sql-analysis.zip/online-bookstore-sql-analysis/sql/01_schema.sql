-- =============================================================
-- Online Bookstore SQL Analysis | 01_schema.sql
-- Database : PostgreSQL 14+
-- Purpose  : Create the three tables (books, customers, orders)
--
-- Before running this script, create the database once and
-- connect to it:
--     CREATE DATABASE onlinebookstore;
-- =============================================================

-- Drop in dependency order (orders references the other two)
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS books;

CREATE TABLE books (
    book_id        SERIAL PRIMARY KEY,
    title          VARCHAR(100)  NOT NULL,
    author         VARCHAR(100)  NOT NULL,
    genre          VARCHAR(50),
    published_year INT,
    price          NUMERIC(10,2) CHECK (price >= 0),
    stock          INT           CHECK (stock >= 0)
);

CREATE TABLE customers (
    customer_id SERIAL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(100),
    phone       VARCHAR(15),
    city        VARCHAR(50),
    country     VARCHAR(150)
);

CREATE TABLE orders (
    order_id     SERIAL PRIMARY KEY,
    customer_id  INT NOT NULL REFERENCES customers (customer_id),
    book_id      INT NOT NULL REFERENCES books (book_id),
    order_date   DATE,
    quantity     INT CHECK (quantity > 0),
    total_amount NUMERIC(10,2)
);
